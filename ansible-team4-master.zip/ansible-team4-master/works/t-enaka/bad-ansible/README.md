# bad-ansible
Bad Ansible is a deliberately poorly written playbook and Ansible Environment for training purposes
