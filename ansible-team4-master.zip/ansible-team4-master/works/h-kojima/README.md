For h-kojima.
