# README

ansible-playbook site.yml

初回osp_fetch : Add host toのあとインスタンスが立ち上がるのに
時間がかかるっぽい。
しばらく時間を置かないと[install apache/httpd]のSSHコネクションでコケる
