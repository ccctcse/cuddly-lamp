Ansible Team 4 Repository.  
作業用に作成したworksディレクトリの中に、各アカウント名のディレクトリを作成して利用してください。

How to Clone

```
$ git clone https://github.com/irixjp/ansible-team4
```

How to Update Local Repository

```
$ git pull
```

How to Add/Change

```
$ git add . # 新規ファイル/ディレクトリ作成時のみ実行
$ git commit -am "added" # コミット時のメッセージ入力
$ git push
Username for 'https://github.com': USERNAME
Password for 'https://USERNAME@github.com': 
Counting objects: 3, done.
Writing objects: 100% (3/3), 240 bytes | 240.00 KiB/s, done.
Total 3 (delta 0), reused 0 (delta 0)
To https://github.com/irixjp/ansible-team4
 * [new branch]      master -> master
```
